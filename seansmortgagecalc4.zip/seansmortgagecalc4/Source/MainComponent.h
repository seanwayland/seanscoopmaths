#ifndef MAINCOMPONENT_H_INCLUDED
#define MAINCOMPONENT_H_INCLUDED

#include "../JuceLibraryCode/JuceHeader.h"

class MainContentComponent   : public Component,
                               private Label::Listener
{
public:
    //==============================================================================
    MainContentComponent()
    {
        addAndMakeVisible (titleLabel);
        titleLabel.setFont (Font (16.0f, Font::bold));
        titleLabel.setText ("Sean's NYC co-op maths calculator...", dontSendNotification);
        titleLabel.setColour (Label::textColourId, Colours::lightgreen);
        titleLabel.setJustificationType (Justification::centred);

        addAndMakeVisible (monthliesLabel);
        monthliesLabel.setText ("Monthlies:", dontSendNotification);
        monthliesLabel.attachToComponent (&monthliesText, true);
        monthliesLabel.setColour (Label::textColourId, Colours::orange);
        monthliesLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (monthliesText);
        monthliesText.setEditable (true);
        monthliesText.setColour (Label::backgroundColourId, Colours::white);
        monthliesText.setColour (Label::textWhenEditingColourId, Colours::black);
        monthliesText.setColour (Label::textColourId, Colours::black);
        monthliesText.addListener (this);
        
        addAndMakeVisible (interestRateLabel);
        interestRateLabel.setText ("Interest rate %:", dontSendNotification);
        interestRateLabel.attachToComponent (&interestRateText, true);
        interestRateLabel.setColour (Label::textColourId, Colours::orange);
        interestRateLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (interestRateText);
        interestRateText.setColour (Label::backgroundColourId, Colours::lightgrey);
        interestRateText.setEditable (true);
        interestRateText.setColour (Label::backgroundColourId, Colours::white);
        interestRateText.setColour (Label::textWhenEditingColourId, Colours::black);
        interestRateText.setColour (Label::textColourId, Colours::black);
        interestRateText.addListener (this);
        
        addAndMakeVisible (monthlyIncomeLabel);
        monthlyIncomeLabel.setText ("Monthly Income:", dontSendNotification);
        monthlyIncomeLabel.attachToComponent (&monthlyIncomeText, true);
        monthlyIncomeLabel.setColour (Label::textColourId, Colours::orange);
        monthlyIncomeLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (monthlyIncomeText);
        monthlyIncomeText.setEditable (true);
        monthlyIncomeText.setColour (Label::backgroundColourId, Colours::white);
        monthlyIncomeText.setColour (Label::textWhenEditingColourId, Colours::black);
        monthlyIncomeText.setColour (Label::textColourId, Colours::black);
        monthlyIncomeText.addListener (this);
        
        addAndMakeVisible (buildingDTILabel);
        buildingDTILabel.setText ("Coop max DTI:", dontSendNotification);
        buildingDTILabel.attachToComponent (&buildingDTIText, true);
        buildingDTILabel.setColour (Label::textColourId, Colours::orange);
        buildingDTILabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (buildingDTIText);
        buildingDTIText.setEditable (true);
        buildingDTIText.setColour (Label::backgroundColourId, Colours::white);
        buildingDTIText.setColour (Label::textWhenEditingColourId, Colours::black);
        buildingDTIText.setColour (Label::textColourId, Colours::black);
        buildingDTIText.addListener (this);
        
        addAndMakeVisible (offerAmountLabel);
        offerAmountLabel.setText ("Offer Amount:", dontSendNotification);
        offerAmountLabel.attachToComponent (&offerAmountText, true);
        offerAmountLabel.setColour (Label::textColourId, Colours::orange);
        offerAmountLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (offerAmountText);
        offerAmountText.setEditable (true);
        offerAmountText.setColour (Label::backgroundColourId, Colours::white);
        offerAmountText.setColour (Label::textWhenEditingColourId, Colours::black);
        offerAmountText.setColour (Label::textColourId, Colours::black);
        offerAmountText.addListener (this);
        
        addAndMakeVisible (downPaymentLabel);
        downPaymentLabel.setText ("Down Payment amt:", dontSendNotification);
        downPaymentLabel.attachToComponent (&downPaymentText, true);
        downPaymentLabel.setColour (Label::textColourId, Colours::orange);
        downPaymentLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (downPaymentText);
        downPaymentText.setEditable (true);
        downPaymentText.setColour (Label::backgroundColourId, Colours::white);
        downPaymentText.setColour (Label::textWhenEditingColourId, Colours::black);
        downPaymentText.setColour (Label::textColourId, Colours::black);
        downPaymentText.addListener (this);
        
        addAndMakeVisible (closingCostsLabel);
        closingCostsLabel.setText ("Closing costs:", dontSendNotification);
        closingCostsLabel.attachToComponent (&closingCostsText, true);
        closingCostsLabel.setColour (Label::textColourId, Colours::orange);
        closingCostsLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (closingCostsText);
        closingCostsText.setEditable (true);
        closingCostsText.setColour (Label::backgroundColourId, Colours::white);
        closingCostsText.setColour (Label::textWhenEditingColourId, Colours::black);
        closingCostsText.setColour (Label::textColourId, Colours::black);
        closingCostsText.addListener (this);
        
        addAndMakeVisible (liquidAssetsLabel);
        liquidAssetsLabel.setText ("Liquid Assets:", dontSendNotification);
        liquidAssetsLabel.attachToComponent (&liquidAssetsText, true);
        liquidAssetsLabel.setColour (Label::textColourId, Colours::orange);
        liquidAssetsLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (liquidAssetsText);
        liquidAssetsText.setEditable (true);
        liquidAssetsText.setColour (Label::backgroundColourId, Colours::white);
        liquidAssetsText.setColour (Label::textWhenEditingColourId, Colours::black);
        liquidAssetsText.setColour (Label::textColourId, Colours::black);
        liquidAssetsText.addListener (this);
        
        addAndMakeVisible (mortgagePaymentLabel);
        mortgagePaymentLabel.setText ("mortgage pmt:", dontSendNotification);
        mortgagePaymentLabel.attachToComponent (&mortgagePaymentText, true);
        mortgagePaymentLabel.setColour (Label::textColourId, Colours::orange);
        mortgagePaymentLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (mortgagePaymentText);
        mortgagePaymentText.setEditable (true);
        mortgagePaymentText.setColour (Label::backgroundColourId, Colours::white);
        mortgagePaymentText.setColour (Label::textWhenEditingColourId, Colours::black);
        mortgagePaymentText.setColour (Label::textColourId, Colours::black);
        mortgagePaymentText.addListener (this);
        
        addAndMakeVisible (DTImaxLabel);
        DTImaxLabel.setText ("DTI max:", dontSendNotification);
        DTImaxLabel.attachToComponent (&DTImaxText, true);
        DTImaxLabel.setColour (Label::textColourId, Colours::orange);
        DTImaxLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (DTImaxText);
        DTImaxText.setEditable (true);
        DTImaxText.setColour (Label::backgroundColourId, Colours::white);
        DTImaxText.setColour (Label::textWhenEditingColourId, Colours::black);
        DTImaxText.setColour (Label::textColourId, Colours::black);
        DTImaxText.addListener (this);
        
        addAndMakeVisible (loanAmountLabel);
        loanAmountLabel.setText ("Loan Amount:", dontSendNotification);
        loanAmountLabel.attachToComponent (&loanAmountText, true);
        loanAmountLabel.setColour (Label::textColourId, Colours::orange);
        loanAmountLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (loanAmountText);
        loanAmountText.setEditable (true);
        loanAmountText.setColour (Label::backgroundColourId, Colours::white);
        loanAmountText.setColour (Label::textWhenEditingColourId, Colours::black);
        loanAmountText.setColour (Label::textColourId, Colours::black);
        loanAmountText.addListener (this);
        
        addAndMakeVisible (DTIcalculatedLabel);
        DTIcalculatedLabel.setText ("DTI calculated:", dontSendNotification);
        DTIcalculatedLabel.attachToComponent (&DTIcalculatedText, true);
        DTIcalculatedLabel.setColour (Label::textColourId, Colours::orange);
        DTIcalculatedLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (DTIcalculatedText);
        DTIcalculatedText.setEditable (true);
        DTIcalculatedText.setColour (Label::backgroundColourId, Colours::white);
        DTIcalculatedText.setColour (Label::textWhenEditingColourId, Colours::black);
        DTIcalculatedText.setColour (Label::textColourId, Colours::black);
        DTIcalculatedText.addListener (this);
        
        addAndMakeVisible (maxLoanAllowedLabel);
        maxLoanAllowedLabel.setText ("Max Loan Allowed:", dontSendNotification);
        maxLoanAllowedLabel.attachToComponent (&maxLoanAllowedText, true);
        maxLoanAllowedLabel.setColour (Label::textColourId, Colours::orange);
        maxLoanAllowedLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (maxLoanAllowedText);
        maxLoanAllowedText.setEditable (true);
        maxLoanAllowedText.setColour (Label::backgroundColourId, Colours::white);
        maxLoanAllowedText.setColour (Label::textWhenEditingColourId, Colours::black);
        maxLoanAllowedText.setColour (Label::textColourId, Colours::black);
        maxLoanAllowedText.addListener (this);
        
        addAndMakeVisible (downPaymentPercentLabel);
        downPaymentPercentLabel.setText ("Down Payment %:", dontSendNotification);
        downPaymentPercentLabel.attachToComponent (&downPaymentPercentText, true);
        downPaymentPercentLabel.setColour (Label::textColourId, Colours::orange);
        downPaymentPercentLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (downPaymentPercentText);
        downPaymentPercentText.setEditable (true);
        downPaymentPercentText.setColour (Label::backgroundColourId, Colours::white);
        downPaymentPercentText.setColour (Label::textWhenEditingColourId, Colours::black);
        downPaymentPercentText.setColour (Label::textColourId, Colours::black);
        downPaymentPercentText.addListener (this);
        
        addAndMakeVisible (twoYearsReserveAmountLabel);
        twoYearsReserveAmountLabel.setText ("2 yrs reserves:", dontSendNotification);
        twoYearsReserveAmountLabel.attachToComponent (&twoYearsReserveAmountText, true);
        twoYearsReserveAmountLabel.setColour (Label::textColourId, Colours::orange);
        twoYearsReserveAmountLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (twoYearsReserveAmountText);
        twoYearsReserveAmountText.setEditable (true);
        twoYearsReserveAmountText.setColour (Label::backgroundColourId, Colours::white);
        twoYearsReserveAmountText.setColour (Label::textWhenEditingColourId, Colours::black);
        twoYearsReserveAmountText.setColour (Label::textColourId, Colours::black);
        twoYearsReserveAmountText.addListener (this);
        
        addAndMakeVisible (reservesAfterClosingLabel);
        reservesAfterClosingLabel.setText ("Reserves post close:", dontSendNotification);
        reservesAfterClosingLabel.attachToComponent (&reservesAfterClosingText, true);
        reservesAfterClosingLabel.setColour (Label::textColourId, Colours::orange);
        reservesAfterClosingLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (reservesAfterClosingText);
        reservesAfterClosingText.setEditable (true);
        reservesAfterClosingText.setColour (Label::backgroundColourId, Colours::white);
        reservesAfterClosingText.setColour (Label::textWhenEditingColourId, Colours::black);
        reservesAfterClosingText.setColour (Label::textColourId, Colours::black);
        reservesAfterClosingText.addListener (this);
        

        
        

 


        

        setSize (400, 550);
    }

    void paint (Graphics& g) override
    {
        g.fillAll (Colours::black);
    }

    void resized() override
    {
        titleLabel.setBounds (10, 10, getWidth() - 20, 30);
        monthliesText.setBounds (100, 50, getWidth() - 110, 20);
        interestRateText.setBounds (100, 80, getWidth() - 110, 20);
        monthlyIncomeText.setBounds(100,110, getWidth() - 110, 20);
        buildingDTIText.setBounds(100,140, getWidth() - 110, 20);
        offerAmountText.setBounds(100,170, getWidth() - 110, 20);
        downPaymentText.setBounds(100,200, getWidth() - 110, 20);
        closingCostsText.setBounds(100,230, getWidth() - 110, 20);
        liquidAssetsText.setBounds(100,260, getWidth() - 110, 20);
        mortgagePaymentText.setBounds(100,290, getWidth() - 110, 20);
        DTImaxText.setBounds(100,320, getWidth() - 110, 20);
        loanAmountText.setBounds(100,350, getWidth() - 110, 20);
        maxLoanAllowedText.setBounds(100,380, getWidth() - 110, 20);
        downPaymentPercentText.setBounds(100,410, getWidth() - 110, 20);
        twoYearsReserveAmountText.setBounds(100,440, getWidth() - 110, 20);
        reservesAfterClosingText.setBounds(100,470, getWidth() - 110, 20);
    }

      void labelTextChanged (Label* label) override
    {
        if (label == &monthliesText)
            monthlies = ( monthliesText.getText());

        if (label == &interestRateText)
            interestRate = ( interestRateText.getText());
        
        if (label == &buildingDTIText)
            buildingDTI = ( buildingDTIText.getText());
        
        if (label == &offerAmountText)
            offerAmount = ( offerAmountText.getText());

        num = monthlies.getIntValue();
//        incomenum = incomenumber.getIntValue();
 //       DTImaxnum = DTImaxnumber.getIntValue();
 //       num = (num + incomenum)*DTImaxnum;
 //       result = String(num);
//        interestRateText.setText(result, dontSendNotification);
        
       // uppercaseText.setText();
            //uppercaseText.setText (inputText.getText().toUpperCase(), dontSendNotification);
    }


private:
    //==============================================================================
    
    String monthlies;
    String interestRate;
    String monthlyIncome;
    String buildingDTI;
    String offerAmount;
    String downPayment;
    String closingCosts;
    String liquidAssets;
    String mortgagePayment;
    String DTImax;
    String loanAmount;
    String DTIcalculated;
    String maxLoanAllowed;
    String downPaymentPercent;
    String twoYearsReserveAmount;
    String reservesAfterClosing;
    
    int num;
    int interestRatenum;
    int monthlyincomenum;
    int buildingDTInum;
    int offerAmountnum;
    int downPaymentnum;
    int closingCostsnum;
    int liquidAssetsnum;
    int mortgagePaymentnum;
    int DTImaxnum;
    int loanAmountnum;
    int DTIcalculatednum;
    int maxLoanAllowednum;
    int downPaymentPercentnum;
    int twoYearsReserveAMount;
    int reservesAfterClosingnum;
    
    Label titleLabel;
    Label monthliesLabel;
    Label monthliesText;
    Label interestRateLabel;
    Label interestRateText;
    Label monthlyIncomeLabel;
    Label monthlyIncomeText;
    Label buildingDTILabel;
    Label buildingDTIText;
    Label offerAmountLabel;
    Label offerAmountText;
    Label downPaymentLabel;
    Label downPaymentText;
    Label closingCostsLabel;
    Label closingCostsText;
    Label liquidAssetsLabel;
    Label liquidAssetsText;
    Label mortgagePaymentLabel;
    Label mortgagePaymentText;
    Label DTImaxLabel;
    Label DTImaxText;
    Label loanAmountLabel;
    Label loanAmountText;
    Label DTIcalculatedLabel;
    Label DTIcalculatedText;
    Label maxLoanAllowedLabel;
    Label maxLoanAllowedText;
    Label downPaymentPercentLabel;
    Label downPaymentPercentText;
    Label twoYearsReserveAmountLabel;
    Label twoYearsReserveAmountText;
    Label reservesAfterClosingLabel;
    Label reservesAfterClosingText;




    
    


    

    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainContentComponent)
};


#endif  // MAINCOMPONENT_H_INCLUDED
