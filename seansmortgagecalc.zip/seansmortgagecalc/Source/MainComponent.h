#ifndef MAINCOMPONENT_H_INCLUDED
#define MAINCOMPONENT_H_INCLUDED

#include "../JuceLibraryCode/JuceHeader.h"

class MainContentComponent   : public Component,
                               private Label::Listener
{
public:
    //==============================================================================
    MainContentComponent()
    {
        addAndMakeVisible (titleLabel);
        titleLabel.setFont (Font (16.0f, Font::bold));
        titleLabel.setText ("Click in the white box to enter some text...", dontSendNotification);
        titleLabel.setColour (Label::textColourId, Colours::lightgreen);
        titleLabel.setJustificationType (Justification::centred);

        addAndMakeVisible (monthliesLabel);
        monthliesLabel.setText ("Monthlies:", dontSendNotification);
        monthliesLabel.attachToComponent (&monthliesText, true);
        monthliesLabel.setColour (Label::textColourId, Colours::orange);
        monthliesLabel.setJustificationType (Justification::right);
        
        addAndMakeVisible (monthliesText);
        monthliesText.setEditable (true);
        monthliesText.setColour (Label::backgroundColourId, Colours::white);
        monthliesText.setColour (Label::textWhenEditingColourId, Colours::black);
        monthliesText.setColour (Label::textColourId, Colours::black);
        monthliesText.addListener (this);

        addAndMakeVisible (interestRateLabel);
        interestRateLabel.setText ("Interest rate %:", dontSendNotification);
        interestRateLabel.attachToComponent (&interestRateText, true);
        interestRateLabel.setColour (Label::textColourId, Colours::orange);
        interestRateLabel.setJustificationType (Justification::right);

        addAndMakeVisible (interestRateText);
        interestRateText.setColour (Label::backgroundColourId, Colours::lightgrey);
        interestRateText.setEditable (true);
        interestRateText.setColour (Label::backgroundColourId, Colours::white);
        interestRateText.setColour (Label::textWhenEditingColourId, Colours::black);
        interestRateText.setColour (Label::textColourId, Colours::black);
        interestRateText.addListener (this);


        

        setSize (320, 200);
    }

    void paint (Graphics& g) override
    {
        g.fillAll (Colours::black);
    }

    void resized() override
    {
        titleLabel.setBounds (10, 10, getWidth() - 20, 30);
        monthliesText.setBounds (100, 50, getWidth() - 110, 20);
        interestRateText.setBounds (100, 80, getWidth() - 110, 20);
    }

    void labelTextChanged (Label* label) override
    {
        if (label == &monthliesText)
            number = ( monthliesText.getText());
        num = number.getIntValue();
        num = num + 1;
        result = String(num);
        interestRateText.setText(result, dontSendNotification);
        
       // uppercaseText.setText();
            //uppercaseText.setText (inputText.getText().toUpperCase(), dontSendNotification);
    }

private:
    //==============================================================================
    Label titleLabel;
    Label monthliesLabel;
    Label monthliesText;
    Label interestRateLabel;
    Label interestRateText;
    String number;
    String result;
    int num;
    

    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainContentComponent)
};


#endif  // MAINCOMPONENT_H_INCLUDED
